from pathlib import Path
from types import SimpleNamespace

import numpy as np

from morphing_waverider.dynamics.integrator import Trajectory
from morphing_waverider.utils.config import project_root


def test_sampled_trajectory_columns_match_time_grid():
    traj = Trajectory(t=np.array([0.,1.,2.]),x=np.zeros((3,4)),u=np.array([[.1],[.2]]),
        eta=np.zeros((3,1)),sub_t=np.array([0.,.5,1.,1.5,2.]),
        sub_x=np.zeros((5,4)),sub_eta=np.zeros((5,1)))
    model = SimpleNamespace(numeric_outputs=lambda x,u,eta:dict(CL=float(u[0])))
    result = traj.sampled(model)
    assert len(result.u) == len(result.t)-1
    assert all(len(values)==len(result.t) for values in result.as_columns().values())
    np.testing.assert_array_equal(result.column('alpha'),[.1,.1,.2,.2,.2])


def test_legacy_config_root_is_independent_of_cwd(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert project_root() == Path(__file__).resolve().parents[1]
