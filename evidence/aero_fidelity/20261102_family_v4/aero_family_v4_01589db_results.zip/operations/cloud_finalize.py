"""Package v4 evidence only. Never change scientific inputs or delete raw results."""
from pathlib import Path
import collections,csv,datetime,hashlib,json,os,re,shutil,subprocess,zipfile
REPO=Path('/hy-tmp/dqn-aero-v4-01589db')
OPS=Path('/hy-tmp/aero_operations_v4_20261102')
OUT=REPO/'runs/aero_fidelity_v4'
SHA='01589db3371acc0f542b4c9b1877db0b6221566d'
PKG=OPS/'delivery_files'
assert not PKG.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,value): p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
audit=read(OUT/'family_selected/family_audit.json')
check=read(OPS/'check_state.json')
assert check['stage']=='CHECK_COMPLETED'
stages={p.name[:-11]:read(p) for p in OPS.glob('*_state.json') if p.name!='check_state.json'}
assert all(s.get('status')!='RUNNING' for s in stages.values()),stages
family=read(OUT/'family/FAMILY_RUN.json')
statuses=[read(p) for p in sorted((OUT/'family').glob('FAM4_*/status.json'))]
assert len(statuses)==29
failures=[s for s in statuses if s['status']!='GENERATED']
categories=dict(collections.Counter(s.get('error_identifier','')+' | '+s.get('error_message','') for s in failures))
PKG.mkdir()
for name in ['family','family_selected']:
    shutil.copytree(OUT/name,PKG/name)
if (OUT/'results').exists(): shutil.copytree(OUT/'results',PKG/'results')
# Retain only requested CFD evidence plus mesh diagnostics and task lists; never upload mesh/restart files.
allowed={'case.json','case.cfg','history.csv','su2.log','mesh_info.json','progress.log','cases_medium.txt','cases_coarse.txt','cases_fine.txt','done'}
for p in sorted((OUT/'cfd').rglob('*')):
    if p.is_file() and p.name in allowed:
        dest=PKG/p.relative_to(OUT); dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dest)
meta=PKG/'operations'; meta.mkdir()
for p in sorted(OPS.iterdir()):
    if p.is_file() and (p.suffix in ('.log','.txt','.py','.sh','.exit') or p.name.endswith('_state.json')):
        shutil.copy2(p,meta/p.name)
env=os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'
with (meta/'upstream_after.log').open('w') as f:
    subprocess.run(['/hy-tmp/dqn-aero/.venv/bin/python','verify_snapshot.py'],cwd=REPO/'upstream_matlab',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
write(PKG/'family_failures.json',failures)
with (PKG/'family_status.csv').open('w',encoding='utf-8',newline='') as f:
    fields=['job_id','Ma_design','delta_deg','a_x','status','elapsed_s','error_identifier','error_message','frozen_audit','valid','reason','audit_reason','volume_m3']
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader()
    sm={s['job_id']:s for s in statuses}
    for row in audit['rows']: w.writerow({**row,**sm[row['job_id']]})
case_records=[]
for p in sorted((OUT/'cfd').glob('*/*/M*_a*/case.json')):
    h=p.parent/'history.csv'; log=p.parent/'su2.log'
    r=dict(case_id=p.parent.relative_to(OUT/'cfd').as_posix(),done=(p.parent/'done').exists(),history_exists=h.exists(),last_residual=None)
    if h.exists():
        try:
            rows=list(csv.reader(h.open(newline='')))
            r['last_history']=dict(zip([x.strip().strip('"') for x in rows[0]],[float(x) for x in rows[-1]]))
            r['last_residual']=r['last_history'].get('rms[Rho]')
        except Exception as e: r['history_parse_error']=repr(e)
    text=log.read_text(errors='replace') if log.exists() else ''
    lines=text.splitlines()
    r['log_tail']=lines[-40:]
    r['warnings']=[x for x in lines if 'Warning:' in x]
    r['nonphysical_points_warning_counts']=[int(x) for x in re.findall(r'there are (\d+) non-physical points',text)]
    r['nonphysical_reconstructed_states_warning_counts']=[int(x) for x in re.findall(r'Warning: (\d+) reconstructed states',text)]
    r['cauchy_CL_pass']=any('Cauchy[CL]' in x and 'Yes' in x for x in lines)
    r['cauchy_CD_pass']=any('Cauchy[CD]' in x and 'Yes' in x for x in lines)
    r['cauchy_evidence']=[x for x in lines if 'Cauchy[CL]' in x or 'Cauchy[CD]' in x]
    r['solver_all_criteria_satisfied']='All convergence criteria satisfied.' in text
    r['solver_exit_success']='Exit Success (SU2_CFD)' in text
    r['density_residual_below_1e_minus5']=r['last_residual'] is not None and r['last_residual'] < -5
    r['converged_by_frozen_rule']=r['done'] and (r['density_residual_below_1e_minus5'] or (r['cauchy_CL_pass'] and r['cauchy_CD_pass']))
    r['observed_case_wall_s']=None
    if r['done'] and log.exists():
        birth=int(subprocess.check_output(['stat','-c','%W',str(log)],text=True).strip())
        if birth>0: r['observed_case_wall_s']=(p.parent/'done').stat().st_mtime-birth
    r['timing_method']='su2.log filesystem birth timestamp (integer seconds) to done timestamp; includes MPI startup and output; approximate, no per-case timer was injected'
    case_records.append(r)
write(PKG/'cfd_case_status.json',case_records)
with (PKG/'cfd_case_status.csv').open('w',encoding='utf-8',newline='') as f:
    fields=['case_id','done','last_residual','cauchy_CL_pass','cauchy_CD_pass','density_residual_below_1e_minus5','converged_by_frozen_rule','observed_case_wall_s','nonphysical_points_warning_counts','nonphysical_reconstructed_states_warning_counts']
    w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); w.writeheader(); w.writerows(case_records)
convergence=dict(converged=sum(c['converged_by_frozen_rule'] for c in case_records),
                 not_converged=[dict(case_id=c['case_id'],last_residual=c['last_residual']) for c in case_records if not c['converged_by_frozen_rule']],
                 cases_with_nonphysical_point_warning=sum(bool(c['nonphysical_points_warning_counts']) for c in case_records),
                 cases_with_nonphysical_reconstruction_warning=sum(bool(c['nonphysical_reconstructed_states_warning_counts']) for c in case_records),
                 warning_interpretation='Literal SU2 warnings preserved; their impact is not established by Cauchy convergence. No new pass/fail criterion is imposed.')
summary=dict(commit=SHA,source_branch='aoa-fix',protocol_version=4,amendment=3,NP=7,JOBS=2,SLICES=4,cpu_quota_cores=10,
             family_counts=dict(collections.Counter(s['status'] for s in statuses)),family_wall_s=family['wall_s'],failure_categories=categories,
             check_wall_s=check['check_wall_s'],check_exit_code=check['check_exit_code'],selection_status=audit['status'],audit_outcomes=audit['outcomes'],
             generated=audit['generated'],valid=audit['valid'],selected=audit.get('selected'),target_volume_m3=1.018813633812261,
             tests='16 passed',upstream_verified_files=203,source_modified=False,stages=stages,
             cfd_executed='cfd-run' in stages,cfd_case_count=len(case_records),cfd_done_count=sum(c['done'] for c in case_records),
             decision_exists=(PKG/'results/decision.json').exists(),convergence=convergence,packaged_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
write(PKG/'RUN_SUMMARY.json',summary)
md=['# 外形族第四版（协议修订 3）执行记录','',f'冻结提交：`{SHA}`（aoa-fix）。','',
    '原始生成器、29 组任务、审计、选择规则和容差均未修改；第一至三版未重跑。MATLAB 在本机运行，其余步骤在云端原提交执行。',
    '', '环境：MATLAB R2023a，Optimization / Symbolic Math 工具箱授权可用；云端 Python 3.11.10、SU2 8.5.0、Open MPI 5.0.11。',
    '', 'NP=7、JOBS=2、SLICES=4；云端实际 CPU 配额 10 核。相关测试 16 passed；运行前后 203 个 upstream_matlab 文件 SHA-256 全部通过。',
    '',f'生成：{audit["generated"]}/29 成功，{len(failures)} 失败，墙钟 {family["wall_s"]:.3f} s。',
    '',f'check：{audit["status"]}；{audit["valid"]} 个有效外形；墙钟 {check["check_wall_s"]:.3f} s。',
    '', '## 生成错误分类','']
md += [f'- {n} 组：{c}' for c,n in categories.items()] or ['无生成失败。']
md += ['', '## check 完整输出','','```text',(OPS/'check.log').read_text().rstrip(),'```','']
if audit['status']=='SELECTED':
    md += ['| 入选构型 | 原任务 | 体积 m³ | 相对目标偏差 |','|---|---|---:|---:|']
    for gid,m in audit['members'].items():
        md.append(f'| {gid} | {m["job_id"]} | {m["volume_m3"]:.12f} | {(m["volume_m3"]/summary["target_volume_m3"]-1)*100:+.6f}% |')
md += ['', '## 后续阶段','']
for name,s in stages.items():
    md.append(f'- {name}: {s.get("status")}, 退出码 {s.get("exit_code")}, 墙钟 {s.get("wall_s",0):.3f} s；完整日志见 operations/{name}.log。')
if not stages: md.append('选择未通过，未运行 CFD 阶段。')
if 'cfd-mesh' in stages and stages['cfd-mesh']['status']=='FAILED':
    md += ['', '网格阶段失败，按冻结流程停止；未运行 cfd-run 或 collect。没有 CFD 残差、decision.json 或 decision.txt，不将缺失数据解释为气动判据未通过。',
           '', '```text','\n'.join((OPS/'cfd-mesh.log').read_text(errors='replace').splitlines()[-40:]),'```']
md += ['',f'CFD case.json 数量 {len(case_records)}；有 done 标志 {summary["cfd_done_count"]}；按冻结残差或 CL/CD Cauchy 规则收敛 {convergence["converged"]}。逐案例日志、警告与末残差见 cfd_case_status.json / csv。',
       '',f'未取得收敛证据的案例及末残差：{convergence["not_converged"]}。rms[Rho] 为 log10 值，密度残差小于 1e-5 对应该值小于 -5。',
       '',f'SU2 非物理解点警告涉及 {convergence["cases_with_nonphysical_point_warning"]} 个案例，非物理迎风重构状态警告涉及 {convergence["cases_with_nonphysical_reconstruction_warning"]} 个案例。原始文字与数量逐案例保留；Cauchy 收敛不确定这些警告对气动力的影响。本报告不改变冻结判据。',
       '', '逐案例耗时由 su2.log 文件创建时间到 done 标志时间估算（起点精度为秒，包含 MPI 启动和输出）；阶段总墙钟由独立计时器记录。',
       '', '压缩包保留全部生成记录和 MATLAB 日志、冻结审计及入选外形、实际产生的 CFD 配置与日志；不含 CFD 网格或 restart 文件。所有原始文件仍保留在云端。','']
if summary['decision_exists']:
    decision=read(PKG/'results/decision.json')
    md += ['## 冻结 collect 原始判定','', '```json',json.dumps(decision.get('decision'),ensure_ascii=False,indent=2),'```','',
           'decision.json 保持原脚本输出。collect 本身不筛选未收敛 history；收敛证据另列以上。网格比较的实际尺寸、棱边重试比例及单元数见各 mesh_info.json。','',
           '负压力阻力/负总阻力条目、网格异号结果和原切换收益统计的覆盖范围见 results/OUTPUT_OBSERVATIONS.md 及 JSON。数值收敛不等于物理正确或网格无关，不能忽略这些输出问题解释冻结判定。','']
(PKG/'RUN_SUMMARY.md').write_text('\n'.join(md),encoding='utf-8')
hashes={p.relative_to(PKG).as_posix():digest(p) for p in sorted(PKG.rglob('*')) if p.is_file()}
(PKG/'SHA256SUMS').write_text(''.join(f'{h}  {n}\n' for n,h in hashes.items()),encoding='utf-8')
archive=OPS/'aero_family_v4_01589db_results.zip'; assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    for p in sorted(PKG.rglob('*')):
        if p.is_file(): z.write(p,p.relative_to(PKG).as_posix())
record=dict(zip=str(archive),sha256=digest(archive),bytes=archive.stat().st_size,manifest_files=len(hashes),summary=summary)
write(OPS/'delivery.json',record)
print(json.dumps(record,ensure_ascii=False),flush=True)
