"""Describe observed output limitations without changing the frozen collect decision."""
from pathlib import Path
import collections,json
REPO=Path('/hy-tmp/dqn-aero-v4-01589db')
OUT=REPO/'runs/aero_fidelity_v4'
d=json.loads((OUT/'results/decision.json').read_text())
raw=d['raw_cases']; rows=d['equal_lift']
negative_pressure=[c for c in raw if c['euler_CD']<0]
negative_total=[dict(geometry=c['geometry'],level=c['level'],mach=c['mach'],alpha_deg=c['alpha_deg'],euler_CD=c['euler_CD'],friction_CD=c['friction_CD'],total_CD=c['euler_CD']+c['friction_CD']) for c in raw if c['euler_CD']+c['friction_CD']<=0]
negative_equal_lift=[r for r in rows if r['model']=='euler' and r['CD_total']<=0]
coverage={}
for model in ('euler','wedge'):
    rs=[r for r in rows if r['model']==model]
    conditions=sorted({(r['mach'],r['CL_target']) for r in rs})
    coverage[model]={}
    for g in sorted({r['geometry'] for r in rs}):
        missing=[dict(mach=m,CL_target=cl) for m,cl in conditions if not any(r['geometry']==g and r['mach']==m and r['CL_target']==cl for r in rs)]
        coverage[model][g]=dict(eligible_for_original_switching_gain=not missing,missing_conditions=missing)
grid=[]
for c in sorted([c for c in raw if c['geometry']=='FAM_MD6' and c['mach']==6 and c['alpha_deg']==4],key=lambda c:('coarse','medium','fine').index(c['level'])):
    mesh=json.loads((OUT/'cfd/FAM_MD6'/c['level']/'mesh_info.json').read_text())
    grid.append(dict(level=c['level'],CL=c['euler_CL'],CD_pressure=c['euler_CD'],mesh=mesh))
obs=dict(frozen_decision=d['decision'],negative_pressure_count_all_levels=len(negative_pressure),
         negative_pressure_count_medium=sum(c['level']=='medium' for c in negative_pressure),negative_pressure_cases=negative_pressure,
         nonpositive_total_drag_at_sampled_alpha=negative_total,nonpositive_total_drag_at_equal_lift=negative_equal_lift,
         switching_gain_coverage=coverage,grid_check_values=grid,original_grid_comparison=d['grid_convergence'],
         interpretation='Observed output issues only; no source, settings or decision criteria changed. Solver convergence does not establish physical correctness or mesh independence. Original decision.json retained byte for byte.')
(OUT/'results/OUTPUT_OBSERVATIONS.json').write_text(json.dumps(obs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
md=['# 原始输出核对记录','', '此记录不改变 decision.json、判据或实验参数。','',
    f'冻结脚本输出 premise_holds={d["decision"]["premise_holds"]}，targets_met={d["decision"].get("targets_met")}。',
    '',f'29 个算例中有 {len(negative_pressure)} 个压力 CD 为负（27 个中网格中 {obs["negative_pressure_count_medium"]} 个）；加入摩擦后的采样点总 CD 非正有 {len(negative_total)} 个。',
    '',f'等升力拟合结果中，Euler+摩擦总 CD 非正条目有 {len(negative_equal_lift)} 个，详见 OUTPUT_OBSERVATIONS.json。',
    '', '## 网格检查实际结果','', '| 等级 | CL | 压力 CD | 四面体数 | 棱边倍率 |','|---|---:|---:|---:|---:|']
for r in grid: md.append(f'| {r["level"]} | {r["CL"]:.12g} | {r["CD_pressure"]:.12g} | {r["mesh"]["cells"]} | {r["mesh"]["edge_scale"]} |')
md += ['', '原 collect 报告中/细网格 CL 相对变化约 3.14%，压力 CD 相对变化约 -115.10%；两级压力 CD 异号且数值接近零，因此同时保留绝对值，不能只看相对百分比。',
       '', '三个网格均 remesh_surface=true；棱边重试倍率分别为 1、1.5、3，所以并非所有局部尺寸统一按同一比例加密。',
       '', '## 原切换收益统计的覆盖范围','']
for model,geoms in coverage.items():
    for g,r in geoms.items(): md.append(f'- {model} / {g}: 进入原脚本完整工况比较={r["eligible_for_original_switching_gain"]}；缺失={r["missing_conditions"]}。')
md += ['', '原脚本将不能覆盖全部目标条件的成员排除后再计算切换收益。报告中的 0% 是该筛选口径下的原始输出，不能忽略缺失条件而解释为完整三成员外形族均无切换收益。',
       '', 'SU2 的非物理解点与迎风重构状态警告另见 cfd_case_status.json。以上问题的原因与影响尚未验证；没有调整参数、筛除算例或替换正式判定。','']
(OUT/'results/OUTPUT_OBSERVATIONS.md').write_text('\n'.join(md),encoding='utf-8')
print(json.dumps({k:v for k,v in obs.items() if k not in ['negative_pressure_cases','nonpositive_total_drag_at_sampled_alpha','nonpositive_total_drag_at_equal_lift']},ensure_ascii=False))
