"""Operations only: verify transferred v3 files, invoke frozen check once, archive evidence."""
from pathlib import Path
import collections,csv,datetime,hashlib,json,os,shutil,subprocess,sys,tarfile,time,zipfile
REPO=Path('/hy-tmp/dqn-aero-v4-01589db')
OPS=Path('/hy-tmp/aero_operations_v4_20261102')
PYTHON='/hy-tmp/dqn-aero/.venv/bin/python'
OUT=REPO/'runs/aero_fidelity_v4'
SHA='01589db3371acc0f542b4c9b1877db0b6221566d'
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,data):
    (OPS/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
assert (OPS/'tests_passed').read_text().strip()=='PASS'
archive=OPS/'family_generated.tar.gz'; assert digest(archive)==sys.argv[1]
assert not OUT.exists(), 'Refusing to overwrite previous output'
OUT.mkdir(parents=True)
with tarfile.open(archive,'r:gz') as tf:
    for m in tf.getmembers():
        assert (OUT/m.name).resolve().is_relative_to(OUT.resolve()) and not m.issym() and not m.islnk(),m.name
    tf.extractall(OUT)
manifest=json.loads((OUT/'family/TRANSFER_SHA256.json').read_text())
for name,h in manifest.items(): assert digest(OUT/'family'/name)==h,name
jobs=json.loads((OUT/'family/jobs.json').read_text())
originals={j['job_id']:j for j in jobs}; assert len(originals)==29
statuses=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'family').glob('FAM4_*/status.json'))]
assert len(statuses)==29 and {s['job_id'] for s in statuses}==set(originals)
assert all(s['inputs10']==originals[s['job_id']]['inputs10'] for s in statuses)
env=os.environ.copy()
env.update(NP='7',JOBS='2',SLICES='4',OUT='runs/aero_fidelity_v4',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
env['PATH']='/hy-tmp/dqn-aero/.venv/bin:/hy-tmp/aero_su2/bin:'+env['PATH']
started=now(); tic=time.monotonic()
save('check_state.json',dict(stage='RUNNING_CHECK',commit=SHA,started_at=started,transferred_files_verified=len(manifest),input_records_verified=29))
with (OPS/'check.log').open('w') as log:
    result=subprocess.run(['bash','experiments/aero_fidelity/run_decision.sh','check'],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
wall=time.monotonic()-tic; finished=now()
print((OPS/'check.log').read_text(),flush=True)
audit_path=OUT/'family_selected/family_audit.json'
if not audit_path.is_file():
    save('check_state.json',dict(stage='CHECK_ERROR_NO_AUDIT',exit_code=result.returncode,wall_s=wall))
    raise RuntimeError('No family_audit.json produced; preserve evidence, no retry')
audit=json.loads(audit_path.read_text())
assert audit['jobs']==29 and len(audit['rows'])==29
assert (result.returncode==0 and audit['status']=='SELECTED') or (result.returncode!=0 and audit['status']=='NO_ADMISSIBLE_FAMILY')
if audit['status']=='SELECTED':
    assert (OUT/'family_selected/select.json').is_file()
    assert len(list((OUT/'family_selected').glob('*/native_geometry.mat')))==3
    for gid,member in audit['members'].items():
        assert digest(OUT/'family_selected'/gid/'native_geometry.mat')==member['sha256']
save('check_state.json',dict(stage='CHECK_COMPLETED',commit=SHA,status=audit['status'],check_exit_code=result.returncode,check_wall_s=wall,started_at=started,finished_at=finished,generated=audit['generated'],valid=audit['valid'],outcomes=audit['outcomes'],selected=audit.get('selected')))
print(json.dumps(json.loads((OPS/'check_state.json').read_text()),ensure_ascii=False),flush=True)
