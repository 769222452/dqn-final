#!/usr/bin/env bash
set -euo pipefail
OPS=/hy-tmp/aero_operations_v2_20261102
exec > >(tee "$OPS/deploy_and_test.log") 2>&1
echo 'caf3f03ef85bbfab0bfdcee41bfe1dfe8145de0c00c0240c47f40bb1380fe317  /hy-tmp/aero_operations_v2_20261102/source_v2.bundle' | sha256sum -c -
cd /hy-tmp/dqn-aero
test -z "$(git status --porcelain --untracked-files=no)"
test "$(git rev-parse HEAD)" = 4d211b1b9cc282bdf7716c6e03ff5c5156c9d4a7
git fetch "$OPS/source_v2.bundle" refs/heads/aoa-fix:refs/remotes/origin/aoa-fix
git checkout aoa-fix
git merge --ff-only refs/remotes/origin/aoa-fix
git rev-parse HEAD | tee "$OPS/FROZEN_COMMIT.txt"
test "$(git rev-parse HEAD)" = 4baf51c6ad962dc646ced8ab4c105b50db131dc0
git status --short
export PATH=/hy-tmp/dqn-aero/.venv/bin:/hy-tmp/aero_su2/bin:$PATH
export NP=7 JOBS=2 SLICES=4 OUT=runs/aero_fidelity_v2
python -m pytest -q tests/test_aero_fidelity.py | tee "$OPS/pytest.log"
echo PASS > "$OPS/tests_passed"
(cd upstream_matlab && python verify_snapshot.py) | tee "$OPS/upstream_verify.log"
{ date -Is; python --version; python -m pip freeze; nproc; lscpu; free -h; df -h /hy-tmp; cat /sys/fs/cgroup/cpu.max; cat /sys/fs/cgroup/memory.max; mpirun --version; conda list -p /hy-tmp/aero_su2 su2; } > "$OPS/environment.txt" 2>&1
set +e
bash experiments/aero_fidelity/run_decision.sh preflight > "$OPS/preflight.log" 2>&1
rc=$?
set -e
cat "$OPS/preflight.log"
echo "$rc" > "$OPS/preflight.exit"
test "$(grep -c '^FAIL ' "$OPS/preflight.log")" = 1
grep -q '^FAIL matlab not found' "$OPS/preflight.log"
echo 'Local licensed MATLAB fallback authorized by user; cloud tests and other preflight requirements passed.'
