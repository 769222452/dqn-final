"""Operations only: verify transfer, invoke frozen check once, preserve all evidence."""
from pathlib import Path
import collections, csv, datetime, hashlib, json, os, shutil, subprocess, sys, tarfile, time, zipfile

REPO=Path('/hy-tmp/dqn-aero')
OPS=Path('/hy-tmp/aero_operations_v2_20261102')
OUT=REPO/'runs/aero_fidelity_v2'
SHA='e33111d30934e3ff1f2f069510127f02c443b4a9'
BASE='4baf51c6ad962dc646ced8ab4c105b50db131dc0'
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,data):
    (OPS/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
archive=OPS/'family_generated.tar.gz'
assert digest(archive)==sys.argv[1]
assert not OUT.exists(), 'Refusing to overwrite existing output'
OUT.mkdir(parents=True)
with tarfile.open(archive,'r:gz') as tf:
    for m in tf.getmembers():
        assert (OUT/m.name).resolve().is_relative_to(OUT.resolve()) and not m.issym() and not m.islnk(),m.name
    tf.extractall(OUT)
manifest=json.loads((OUT/'family/TRANSFER_SHA256.json').read_text())
for name,h in manifest.items(): assert digest(OUT/'family'/name)==h,name
statuses=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'family').glob('FAM2_*/status.json'))]
assert len(statuses)==180
assert len({s['job_id'] for s in statuses})==180
env=os.environ.copy()
env.update(NP='7',JOBS='2',SLICES='4',OUT='runs/aero_fidelity_v2',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
env['PATH']=str(REPO/'.venv/bin')+':/hy-tmp/aero_su2/bin:'+env['PATH']
start=time.monotonic()
start_iso=datetime.datetime.now(datetime.timezone.utc).isoformat()
save('check_state.json',dict(stage='RUNNING_CHECK',commit=SHA,started_at=start_iso,transferred_files_verified=len(manifest)))
with (OPS/'check.log').open('w') as log:
    result=subprocess.run(['bash','experiments/aero_fidelity/run_decision.sh','check'],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
wall=time.monotonic()-start
print((OPS/'check.log').read_text(),flush=True)
audit_path=OUT/'family_selected/family_audit.json'
if not audit_path.is_file():
    save('check_state.json',dict(stage='CHECK_ERROR_NO_AUDIT',exit_code=result.returncode,wall_s=wall))
    raise RuntimeError('check produced no family_audit.json; preserved logs, no retry')
audit=json.loads(audit_path.read_text())
assert audit['jobs']==180 and len(audit['rows'])==180
assert (result.returncode==0 and audit['status']=='SELECTED') or (result.returncode!=0 and audit['status']=='NO_ADMISSIBLE_FAMILY')
if audit['status']=='SELECTED':
    assert (OUT/'family_selected/select.json').exists()
    assert len(list((OUT/'family_selected').glob('*/native_geometry.mat')))==3
failures=[s for s in statuses if s['status']!='GENERATED']
categories=dict(collections.Counter((s.get('error_identifier') or 'NO_IDENTIFIER')+' | '+s.get('error_message','') for s in failures))
family=json.loads((OUT/'family/FAMILY_RUN.json').read_text())
summary=dict(commit=SHA,base_commit=BASE,source_branch='aero-family-v2-results-20261102',protocol_version=2,amendment=1,NP=7,JOBS=2,SLICES=4,
    family_counts=dict(collections.Counter(s['status'] for s in statuses)),family_wall_s=family['wall_s'],
    family_started_at=family['original_started_at'],family_finished_at=family['updated_at'],failure_categories=categories,
    initial_attempt_wall_s=family['initial_attempt_wall_s'],resume_wall_s=family['resume_wall_s'],family_end_to_end_wall_s=family['end_to_end_wall_s'],
    compatibility_fix='User-authorized cell/struct task loading only; first 45 task records retained, remaining 135 executed once',
    check_started_at=start_iso,check_finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    check_wall_s=wall,check_exit_code=result.returncode,selection_status=audit['status'],audit_outcomes=audit['outcomes'],
    generated=audit['generated'],valid=audit['valid'],tests='10 passed',upstream_verified_files=203,
    preflight='Cloud lacks MATLAB only; user-authorized local MATLAB R2023a with required toolboxes used',
    cfd_executed=False,transfer_verified_files=len(manifest))
(OUT/'RUN_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'family_failures.json').write_text(json.dumps(failures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'family_status.csv').open('w',encoding='utf-8',newline='') as f:
    fields=['job_id','status','elapsed_s','error_identifier','error_message','frozen_audit','valid','reason','audit_reason','volume_m3']
    writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); writer.writeheader()
    sm={s['job_id']:s for s in statuses}
    for row in audit['rows']: writer.writerow(dict(sm[row['job_id']],**{k:row.get(k) for k in fields if k not in sm[row['job_id']]}))
md=['# 外形族第二版（协议修订 1）执行记录','',f'协议基础提交：`{BASE}`（aoa-fix）；实际执行提交：`{SHA}`（aero-family-v2-results-20261102）。',
    '', '首次运行因任务 JSON 字段不同导致 MATLAB cell/struct 读取不兼容，3 个进程在生成前退出；另一个完成 45 组。用户授权后仅修复 make_family.m 的任务读取方式，原 45 个状态记录逐字节保留，仅补跑缺失的 135 组。完整原始日志及补丁均在 family/ 内。上游生成器、180 组任务输入、审计、选择规则均不变。',
    '', '仅执行版本 2 的 family 和 check；第一版未重跑，未执行任何 CFD 阶段。',
    '', '环境：本机 MATLAB R2023a，Optimization、Symbolic Math 工具箱可用；按已授权异机流程调用原始 make_family。云端 Python 3.11.10，SU2 8.5.0，Open MPI 5.0.11。NP=7、JOBS=2、SLICES=4；check 使用冻结脚本的 4 个进程。云端容器 CPU 配额 10 核。',
    '', '相关测试：10 passed；upstream_matlab 203 个文件 SHA-256 全部一致。',
    '',f'生成：{summary["family_counts"]}；两次执行墙钟合计 {family["wall_s"]:.3f} s（含 MATLAB 启动）；初次 {family["initial_attempt_wall_s"]:.3f} s，续跑 {family["resume_wall_s"]:.3f} s；包含排障间隔的端到端耗时 {family["end_to_end_wall_s"]:.3f} s。',
    '',f'冻结 check：`{audit["status"]}`；耗时 {wall:.3f} s；退出码 {result.returncode}。',
    '',f'审计分类：`{json.dumps(audit["outcomes"],ensure_ascii=False)}`。',
    '', '## 生成失败分类','']
for category,count in categories.items(): md.append(f'- {count} 组：`{category}`')
md+=['','全部失败 job_id 及原始错误见 family_failures.json；180 行逐任务结果见 family_status.csv。',
    '', '## check 完整输出','','```text',(OPS/'check.log').read_text().rstrip(),'```','',
    '完整逐任务原生审计与选择候选：family_selected/family_audit.json。']
md.append('已保存 select.json 和选中的三个 .mat。' if audit['status']=='SELECTED' else '未选出满足冻结规则的外形族，因此没有 select.json 或三个入选 .mat；所有生成的原始 .mat 均保留。')
md+=['','全部失败和日志已保留；未扩大扫描、放宽容许值或修改规则。SHA256SUMS 覆盖包内所有证据文件（不含清单自身）。','']
(OUT/'RUN_SUMMARY.md').write_text('\n'.join(md),encoding='utf-8')
metadata=OUT/'operations'; metadata.mkdir()
for name in ['deploy_and_test.sh','deploy_and_test.log','deploy_compatibility_fix.sh','deploy_compatibility_fix.log','authorized_compatibility_fix.patch','pytest.log','pytest_compatibility.log','preflight.log','environment.txt','environment_extra.txt','upstream_verify.log','check.log','cloud_check_and_package.py']:
    p=OPS/name
    if p.is_file(): shutil.copy2(p,metadata/name)
subprocess.run([str(REPO/'.venv/bin/python'),'verify_snapshot.py'],cwd=REPO/'upstream_matlab',check=True,stdout=(metadata/'upstream_post_verify.log').open('w'))
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
hashes={p.relative_to(OUT).as_posix():digest(p) for p in sorted(OUT.rglob('*')) if p.is_file()}
(OUT/'SHA256SUMS').write_text(''.join(f'{h}  {name}\n' for name,h in hashes.items()),encoding='utf-8')
delivery=OPS/'aero_family_v2_4baf51c_results.zip'
assert not delivery.exists()
with zipfile.ZipFile(delivery,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p,arcname=p.relative_to(OUT).as_posix())
record=dict(zip=str(delivery),sha256=digest(delivery),bytes=delivery.stat().st_size,manifest_files=len(hashes),summary=summary)
save('delivery.json',record)
save('check_state.json',dict(stage='DELIVERY_READY',commit=SHA,selection_status=audit['status'],check_wall_s=wall,delivery=record))
print(json.dumps(record,ensure_ascii=False),flush=True)
