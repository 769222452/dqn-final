#!/usr/bin/env bash
set -euo pipefail
OPS=/hy-tmp/aero_operations_v2_20261102
exec > >(tee "$OPS/deploy_compatibility_fix.log") 2>&1
cd /hy-tmp/dqn-aero
test -z "$(git status --porcelain --untracked-files=no)"
test "$(git rev-parse HEAD)" = 4baf51c6ad962dc646ced8ab4c105b50db131dc0
echo '264a43831b2d1beb1e45a32b613e10efa01698c9b4686a24ed9e1047bec19022  /hy-tmp/aero_operations_v2_20261102/compatibility_fix.bundle' | sha256sum -c -
git fetch "$OPS/compatibility_fix.bundle" HEAD
git switch -c aero-family-v2-results-20261102 FETCH_HEAD
test "$(git rev-parse HEAD)" = e33111d30934e3ff1f2f069510127f02c443b4a9
test "$(git diff --name-only 4baf51c HEAD)" = experiments/aero_fidelity/family/make_family.m
git diff 4baf51c HEAD | tee "$OPS/authorized_compatibility_fix.patch"
export PATH=/hy-tmp/dqn-aero/.venv/bin:/hy-tmp/aero_su2/bin:$PATH
export NP=7 JOBS=2 SLICES=4 OUT=runs/aero_fidelity_v2
python -m pytest -q tests/test_aero_fidelity.py | tee "$OPS/pytest_compatibility.log"
{ echo 'cgroup v1 CPU quota / period / memory limit:'; cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us /sys/fs/cgroup/cpu/cpu.cfs_period_us /sys/fs/cgroup/memory/memory.limit_in_bytes; mpirun --version; ls /hy-tmp/aero_su2/conda-meta/su2-*.json; git rev-parse HEAD; git status --short; } > "$OPS/environment_extra.txt" 2>&1
echo READY_FOR_FAMILY_TRANSFER
