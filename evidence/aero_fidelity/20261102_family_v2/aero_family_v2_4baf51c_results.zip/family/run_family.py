"""Operations wrapper for the documented local MATLAB fallback; frozen scientific code is untouched."""
from pathlib import Path
import collections, ctypes, datetime, hashlib, json, os, shutil, subprocess, tarfile, time, traceback

OPS=Path(__file__).resolve().parent
REPO=Path(r'D:\aero-v2-4baf51c')
FAM=REPO/'runs/aero_fidelity_v2/family'
SHA='4baf51c6ad962dc646ced8ab4c105b50db131dc0'
STATE={'commit':SHA,'started_at':datetime.datetime.now().astimezone().isoformat()}
def state(**kw):
    STATE.update(kw,updated_at=datetime.datetime.now().astimezone().isoformat())
    tmp=OPS/'family_state.tmp'
    tmp.write_text(json.dumps(STATE,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    tmp.replace(OPS/'family_state.json')
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    with (OPS/'family_started.lock').open('x') as f: f.write(str(os.getpid()))
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
    assert not FAM.exists(), 'Refusing to overwrite existing family output'
    env=os.environ.copy()
    env.pop('MP_PW',None)
    env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NP='7',JOBS='2',SLICES='4')
    jobcmd=[r'D:\v6-mission-morph-clean\.venv\Scripts\python.exe','experiments/aero_fidelity/family/family_jobs.py','--out',str(FAM),'--slices','4','--version','2']
    started=time.monotonic()
    subprocess.run(jobcmd,cwd=REPO,env=env,check=True)
    assert len(json.loads((FAM/'jobs.json').read_text()))==180
    for name in ['matlab_preflight.log','SOURCE_ACQUISITION.json']:
        shutil.copy2(OPS/name,FAM/name)
    workers=[]; logs=[]; commands=[]
    for k in range(4):
        expr=f"addpath('{REPO/'experiments/aero_fidelity/family'}'); make_family('{FAM/f'jobs_{k}.json'}', '{REPO/'upstream_matlab/source/matlab/active'}', '{FAM}')"
        args=[r'D:\matlab\bin\matlab.exe','-wait','-batch',expr]
        log=(FAM/f'matlab_{k}.log').open('wb'); logs.append(log)
        workers.append(subprocess.Popen(args,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW))
        commands.append(args)
    state(stage='family_running',workers=[p.pid for p in workers],commands=commands,job_command=jobcmd)
    while any(p.poll() is None for p in workers):
        counts=collections.Counter()
        for p in FAM.glob('FAM2_*/status.json'):
            try: counts[json.loads(p.read_text(encoding='utf-8'))['status']]+=1
            except (OSError,json.JSONDecodeError): pass
        state(counts=dict(counts),wall_s=time.monotonic()-started,worker_exit_codes=[p.poll() for p in workers])
        time.sleep(10)
    for f in logs: f.close()
    codes=[p.returncode for p in workers]
    wall=time.monotonic()-started
    assert not any(codes), f'MATLAB process failure: {codes}; no automatic retry'
    statuses=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(FAM.glob('FAM2_*/status.json'))]
    assert len(statuses)==180, len(statuses)
    counts=dict(collections.Counter(s['status'] for s in statuses))
    state(stage='family_completed',counts=counts,wall_s=wall,worker_exit_codes=codes)
    (FAM/'FAMILY_RUN.json').write_text(json.dumps(dict(STATE,execution_location='local licensed MATLAB R2023a',NP=7,JOBS=2,SLICES=4),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (OPS/'family_failures.json').write_text(json.dumps([s for s in statuses if s['status']!='GENERATED'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    hashes={p.relative_to(FAM).as_posix():digest(p) for p in sorted(FAM.rglob('*')) if p.is_file()}
    (FAM/'TRANSFER_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
    archive=OPS/'family_generated.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=3) as tf: tf.add(FAM,arcname='family')
    state(stage='READY_FOR_CLOUD_CHECK',archive=str(archive),archive_sha256=digest(archive),archive_bytes=archive.stat().st_size)
    print(json.dumps(STATE,ensure_ascii=False),flush=True)
try:
    main()
except Exception as exc:
    state(stage='FAILED',error=f'{type(exc).__name__}: {exc}')
    traceback.print_exc()
    raise
finally:
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
