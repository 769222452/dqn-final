"""Resume missing v2 jobs after the user-authorized MATLAB record-loading fix."""
from pathlib import Path
import collections, ctypes, datetime, hashlib, json, os, shutil, subprocess, tarfile, time, traceback
OPS=Path(__file__).resolve().parent
REPO=Path(r'D:\aero-v2-4baf51c')
FAM=REPO/'runs/aero_fidelity_v2/family'
SHA='e33111d30934e3ff1f2f069510127f02c443b4a9'
BASE='4baf51c6ad962dc646ced8ab4c105b50db131dc0'
STATE={'commit':SHA,'base_commit':BASE,'started_at':datetime.datetime.now().astimezone().isoformat()}
def state(**kw):
    STATE.update(kw,updated_at=datetime.datetime.now().astimezone().isoformat())
    tmp=OPS/'resume_state.tmp'; tmp.write_text(json.dumps(STATE,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); tmp.replace(OPS/'resume_state.json')
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def main():
    with (OPS/'resume_started.lock').open('x') as f: f.write(str(os.getpid()))
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
    changed=subprocess.check_output(['git','diff','--name-only',BASE,SHA],cwd=REPO,text=True).splitlines()
    assert changed==['experiments/aero_fidelity/family/make_family.m'],changed
    old=json.loads((OPS/'family_state.json').read_text())
    assert old['stage']=='FAILED'
    for name in ['family_state.json','family_runner.log','family_runner.err','run_family.py','resume_family.py']:
        shutil.copy2(OPS/name,FAM/('initial_'+name if name.startswith('family_') else name))
    patch=subprocess.check_output(['git','diff',BASE,SHA],cwd=REPO)
    (FAM/'AUTHORIZED_COMPATIBILITY_FIX.patch').write_bytes(patch)
    jobs=json.loads((FAM/'jobs.json').read_text()); assert len(jobs)==180
    existing={p.parent.name:digest(p) for p in FAM.glob('FAM2_*/status.json')}
    pending=[j for j in jobs if j['job_id'] not in existing]
    assert len(existing)==45 and len(pending)==135
    env=os.environ.copy(); env.pop('MP_PW',None)
    env.update(OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1',NP='7',JOBS='2',SLICES='4')
    workers=[]; logs=[]; commands=[]; started=time.monotonic()
    for k in range(4):
        jobfile=FAM/f'jobs_resume_{k}.json'
        jobfile.write_text(json.dumps(pending[k::4],indent=1),encoding='utf-8')
        expr=f"addpath('{REPO/'experiments/aero_fidelity/family'}'); make_family('{jobfile}', '{REPO/'upstream_matlab/source/matlab/active'}', '{FAM}')"
        args=[r'D:\matlab\bin\matlab.exe','-wait','-batch',expr]
        log=(FAM/f'matlab_resume_{k}.log').open('xb'); logs.append(log)
        workers.append(subprocess.Popen(args,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)); commands.append(args)
    state(stage='RESUME_RUNNING',commands=commands,previous_records=45,pending=135,workers=[p.pid for p in workers])
    while any(p.poll() is None for p in workers):
        counts=collections.Counter()
        for p in FAM.glob('FAM2_*/status.json'):
            try: counts[json.loads(p.read_text(encoding='utf-8'))['status']]+=1
            except (OSError,json.JSONDecodeError): pass
        state(counts=dict(counts),resume_wall_s=time.monotonic()-started,worker_exit_codes=[p.poll() for p in workers]); time.sleep(10)
    for f in logs: f.close()
    codes=[p.returncode for p in workers]; wall=time.monotonic()-started
    assert not any(codes),codes
    for jid,h in existing.items(): assert digest(FAM/jid/'status.json')==h,jid
    statuses=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(FAM.glob('FAM2_*/status.json'))]
    assert len(statuses)==180
    counts=dict(collections.Counter(s['status'] for s in statuses))
    initial_wall=(datetime.datetime.fromisoformat(old['updated_at'])-datetime.datetime.fromisoformat(old['started_at'])).total_seconds()
    state(stage='FAMILY_COMPLETED',counts=counts,resume_wall_s=wall,initial_attempt_wall_s=initial_wall,wall_s=initial_wall+wall,worker_exit_codes=codes)
    run=dict(STATE,NP=7,JOBS=2,SLICES=4,execution_location='local licensed MATLAB R2023a',initial_attempt=old,initial_records_preserved=45,remaining_executed_once=135,
             original_started_at=old['started_at'],end_to_end_wall_s=(datetime.datetime.now().astimezone()-datetime.datetime.fromisoformat(old['started_at'])).total_seconds())
    (FAM/'FAMILY_RUN.json').write_text(json.dumps(run,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (OPS/'family_failures.json').write_text(json.dumps([s for s in statuses if s['status']!='GENERATED'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    hashes={p.relative_to(FAM).as_posix():digest(p) for p in sorted(FAM.rglob('*')) if p.is_file()}
    (FAM/'TRANSFER_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
    archive=OPS/'family_generated.tar.gz'
    assert not archive.exists()
    with tarfile.open(archive,'w:gz',compresslevel=3) as tf: tf.add(FAM,arcname='family')
    state(stage='READY_FOR_CLOUD_CHECK',archive=str(archive),archive_sha256=digest(archive),archive_bytes=archive.stat().st_size)
    print(json.dumps(STATE,ensure_ascii=False),flush=True)
try: main()
except Exception as exc:
    state(stage='FAILED',error=f'{type(exc).__name__}: {exc}'); traceback.print_exc(); raise
finally: ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
