#!/usr/bin/env bash
set -euo pipefail
OPS=/hy-tmp/aero_operations_v3_20261102
exec > >(tee "$OPS/cloud_prepare.log") 2>&1
SHA=78378fab661eff81b0840417a1f7616acf451454
REPO=/hy-tmp/dqn-aero-v3-78378fa
cd /hy-tmp/dqn-aero
test ! -d "$REPO"
git merge-base --is-ancestor aoa-fix "$SHA"
git branch -f aoa-fix "$SHA"
git worktree add "$REPO" aoa-fix
cd "$REPO"
test "$(git rev-parse HEAD)" = "$SHA"
test "$(git branch --show-current)" = aoa-fix
test -z "$(git status --porcelain)"
git rev-parse HEAD | tee "$OPS/FROZEN_COMMIT.txt"
export PATH=/hy-tmp/dqn-aero/.venv/bin:/hy-tmp/aero_su2/bin:$PATH
export PYTHONDONTWRITEBYTECODE=1
export NP=7 JOBS=2 SLICES=4 OUT=runs/aero_fidelity_v3
(cd upstream_matlab && python verify_snapshot.py) | tee "$OPS/upstream_before.log"
python -m pytest -q -p no:cacheprovider tests/test_aero_fidelity.py | tee "$OPS/pytest.log"
echo PASS > "$OPS/tests_passed"
{ date -Is; python --version; python -m pip freeze; nproc; lscpu; free -h; df -h /hy-tmp; cat /sys/fs/cgroup/cpu/cpu.cfs_quota_us /sys/fs/cgroup/cpu/cpu.cfs_period_us /sys/fs/cgroup/memory/memory.limit_in_bytes; mpirun --version; ls /hy-tmp/aero_su2/conda-meta/su2-*.json; } > "$OPS/environment.txt" 2>&1
set +e
bash experiments/aero_fidelity/run_decision.sh preflight > "$OPS/preflight.log" 2>&1
rc=$?
set -e
echo "$rc" > "$OPS/preflight.exit"
cat "$OPS/preflight.log"
test "$(grep -c '^FAIL ' "$OPS/preflight.log")" = 1
grep -q '^FAIL matlab not found' "$OPS/preflight.log"
echo 'Local licensed MATLAB fallback explicitly authorized; cloud prerequisites passed.'
test -z "$(git status --porcelain --untracked-files=no)"
