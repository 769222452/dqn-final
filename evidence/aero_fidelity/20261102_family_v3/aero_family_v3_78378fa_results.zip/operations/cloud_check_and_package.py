"""Operations only: verify transferred v3 files, invoke frozen check once, archive evidence."""
from pathlib import Path
import collections,csv,datetime,hashlib,json,os,shutil,subprocess,sys,tarfile,time,zipfile
REPO=Path('/hy-tmp/dqn-aero-v3-78378fa')
OPS=Path('/hy-tmp/aero_operations_v3_20261102')
PYTHON='/hy-tmp/dqn-aero/.venv/bin/python'
OUT=REPO/'runs/aero_fidelity_v3'
SHA='78378fab661eff81b0840417a1f7616acf451454'
def digest(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,data):
    (OPS/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SHA
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
assert (OPS/'tests_passed').read_text().strip()=='PASS'
archive=OPS/'family_generated.tar.gz'; assert digest(archive)==sys.argv[1]
assert not OUT.exists(), 'Refusing to overwrite previous output'
OUT.mkdir(parents=True)
with tarfile.open(archive,'r:gz') as tf:
    for m in tf.getmembers():
        assert (OUT/m.name).resolve().is_relative_to(OUT.resolve()) and not m.issym() and not m.islnk(),m.name
    tf.extractall(OUT)
manifest=json.loads((OUT/'family/TRANSFER_SHA256.json').read_text())
for name,h in manifest.items(): assert digest(OUT/'family'/name)==h,name
jobs=json.loads((OUT/'family/jobs.json').read_text())
originals={j['job_id']:j for j in jobs}; assert len(originals)==189
statuses=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'family').glob('FAM3_*/status.json'))]
assert len(statuses)==189 and {s['job_id'] for s in statuses}==set(originals)
assert all(s['inputs10']==originals[s['job_id']]['inputs10'] for s in statuses)
env=os.environ.copy()
env.update(NP='7',JOBS='2',SLICES='4',OUT='runs/aero_fidelity_v3',PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='1')
env['PATH']='/hy-tmp/dqn-aero/.venv/bin:/hy-tmp/aero_su2/bin:'+env['PATH']
started=now(); tic=time.monotonic()
save('check_state.json',dict(stage='RUNNING_CHECK',commit=SHA,started_at=started,transferred_files_verified=len(manifest),input_records_verified=189))
with (OPS/'check.log').open('w') as log:
    result=subprocess.run(['bash','experiments/aero_fidelity/run_decision.sh','check'],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT)
wall=time.monotonic()-tic; finished=now()
print((OPS/'check.log').read_text(),flush=True)
audit_path=OUT/'family_selected/family_audit.json'
if not audit_path.is_file():
    save('check_state.json',dict(stage='CHECK_ERROR_NO_AUDIT',exit_code=result.returncode,wall_s=wall))
    raise RuntimeError('No family_audit.json produced; preserve evidence, no retry')
audit=json.loads(audit_path.read_text())
assert audit['jobs']==189 and len(audit['rows'])==189
assert (result.returncode==0 and audit['status']=='SELECTED') or (result.returncode!=0 and audit['status']=='NO_ADMISSIBLE_FAMILY')
if audit['status']=='SELECTED':
    assert (OUT/'family_selected/select.json').is_file()
    assert len(list((OUT/'family_selected').glob('*/native_geometry.mat')))==3
    for gid,member in audit['members'].items():
        assert digest(OUT/'family_selected'/gid/'native_geometry.mat')==member['sha256']
failures=[s for s in statuses if s['status']!='GENERATED']
categories=dict(collections.Counter((s.get('error_identifier') or 'NO_IDENTIFIER')+' | '+s.get('error_message','') for s in failures))
family=json.loads((OUT/'family/FAMILY_RUN.json').read_text())
summary=dict(commit=SHA,source_branch='aoa-fix',protocol_version=3,amendment=2,NP=7,JOBS=2,SLICES=4,
    family_counts=dict(collections.Counter(s['status'] for s in statuses)),family_wall_s=family['wall_s'],
    family_started_at=family['started_at'],family_finished_at=family['updated_at'],failure_categories=categories,
    check_started_at=started,check_finished_at=finished,check_wall_s=wall,check_exit_code=result.returncode,
    selection_status=audit['status'],audit_outcomes=audit['outcomes'],generated=audit['generated'],valid=audit['valid'],
    selected=audit.get('selected'),target_volume_m3=jobs[0]['target_volume_m3'],tests='13 passed',upstream_verified_files=203,
    preflight='Cloud lacks MATLAB only; explicitly authorized local MATLAB R2023a with required toolboxes used',
    cfd_executed=False,source_modified=False,transfer_verified_files=len(manifest),input_records_verified=189)
(OUT/'family_failures.json').write_text(json.dumps(failures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'family_status.csv').open('w',encoding='utf-8',newline='') as f:
    fields=['job_id','Ma_design','delta_deg','a_x','status','elapsed_s','error_identifier','error_message','frozen_audit','valid','reason','audit_reason','volume_m3']
    writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore'); writer.writeheader()
    sm={s['job_id']:s for s in statuses}
    for row in audit['rows']: writer.writerow(dict(sm[row['job_id']],**{k:row.get(k) for k in fields if k not in sm[row['job_id']]}))
meta=OUT/'operations'; meta.mkdir()
for name in ['cloud_prepare.sh','cloud_prepare.log','pytest.log','preflight.log','preflight.exit','environment.txt','upstream_before.log','check.log','cloud_check_and_package.py']:
    shutil.copy2(OPS/name,meta/name)
with (meta/'upstream_after.log').open('w') as log:
    subprocess.run([PYTHON,'verify_snapshot.py'],cwd=REPO/'upstream_matlab',env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=REPO,text=True).strip()
(OUT/'RUN_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
md=['# 外形族第三版（协议修订 2）执行记录','',f'冻结提交：`{SHA}`（aoa-fix）。',
    '', '本次仅执行第三版 family / check；前两版未重跑，未执行 cfd-mesh、cfd-run、collect。未修改源码、参数、扫描范围、审计或选择规则。',
    '', '本机 MATLAB R2023a，Optimization 与 Symbolic Math 工具箱可用；按用户授权异机流程执行原始 make_family.m。云端 Python 3.11.10，SU2 8.5.0，Open MPI 5.0.11。NP=7、JOBS=2、SLICES=4；容器 CPU 配额 10 核。',
    '', '相关测试：13 passed。运行前后 upstream_matlab 全部 203 个源文件的大小、SHA-256 及文件清单一致。PYTHONDONTWRITEBYTECODE=1 仅禁止生成 Python 字节码缓存，避免向冻结源目录写入缓存。',
    '',f'任务：189 组；目标体积 {summary["target_volume_m3"]} m³，容差 ±3%。',
    '',f'生成：{summary["family_counts"]}；墙钟耗时 {family["wall_s"]:.3f} s（含 MATLAB 启动）。189 份状态记录的输入逐项与原始任务清单一致。',
    '',f'check：`{audit["status"]}`；墙钟耗时 {wall:.3f} s；退出码 {result.returncode}。',
    '',f'审计分类：`{json.dumps(audit["outcomes"],ensure_ascii=False)}`。',
    '', '## 生成失败分类','']
for category,count in categories.items(): md.append(f'- {count} 组：`{category}`')
if not categories: md.append('无生成失败。')
md+=['','全部失败 job_id 与原始错误见 family_failures.json；全部任务见 family_status.csv。',
     '', '## check 完整输出','','```text',(OPS/'check.log').read_text().rstrip(),'```','',
     '逐任务冻结审计与所有候选见 family_selected/family_audit.json。']
md.append('已保存 select.json 和三个入选 .mat，且它们的哈希与审计记录一致。' if audit['status']=='SELECTED' else '没有可入选外形族，故没有 select.json 或三个入选 .mat；所有生成的原始 .mat 均保留。')
md+=['','全部 MATLAB 日志、任务输入、生成成功及失败记录均保留。SHA256SUMS 覆盖包内全部证据文件，不含清单自身。','']
(OUT/'RUN_SUMMARY.md').write_text('\n'.join(md),encoding='utf-8')
hashes={p.relative_to(OUT).as_posix():digest(p) for p in sorted(OUT.rglob('*')) if p.is_file()}
(OUT/'SHA256SUMS').write_text(''.join(f'{h}  {name}\n' for name,h in hashes.items()),encoding='utf-8')
delivery=OPS/'aero_family_v3_78378fa_results.zip'; assert not delivery.exists()
with zipfile.ZipFile(delivery,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file(): z.write(p,arcname=p.relative_to(OUT).as_posix())
record=dict(zip=str(delivery),sha256=digest(delivery),bytes=delivery.stat().st_size,manifest_files=len(hashes),summary=summary)
save('delivery.json',record)
save('check_state.json',dict(stage='DELIVERY_READY',commit=SHA,selection_status=audit['status'],check_wall_s=wall,delivery=record))
print(json.dumps(record,ensure_ascii=False),flush=True)
